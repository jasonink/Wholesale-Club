#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    current_row = 0;
    ui->setupUi(this);

    ui->tableWidget->setRowCount(10);
    ui->tableWidget->setColumnCount(3);
    ui->tableWidget->setItem(1,1,new QTableWidgetItem("Hello"));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::updateTable()
{
    ui->tableWidget->setItem(current_row,0,new QTableWidgetItem(ui->lineEdit->text()));
    ui->tableWidget->setItem(current_row,1,new QTableWidgetItem(ui->lineEdit_2->text()));
    ui->tableWidget->setItem(current_row,2,new QTableWidgetItem(ui->lineEdit_3->text()));
    ++current_row;

}
